import { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Play, Pause, RotateCcw, Award, Clipboard, Timer as WatchIcon, ListFilter, Trash2 } from 'lucide-react';
import { Lap } from '../types';

export default function StopwatchTab() {
  const [isRunning, setIsRunning] = useState<boolean>(false);
  const [time, setTime] = useState<number>(0); // Total milliseconds
  const [laps, setLaps] = useState<Lap[]>([]);
  
  const timerRef = useRef<number | null>(null);
  const startTimeRef = useRef<number>(0);
  const accumulatedTimeRef = useRef<number>(0);
  
  // For individual lap calculation
  const lastLapTimeRef = useRef<number>(0);

  useEffect(() => {
    return () => {
      if (timerRef.current) {
        window.cancelAnimationFrame(timerRef.current);
      }
    };
  }, []);

  const startStopwatch = () => {
    if (isRunning) return;
    setIsRunning(true);
    startTimeRef.current = performance.now() - accumulatedTimeRef.current;
    
    const updateTime = () => {
      const current = performance.now();
      const elapsed = current - startTimeRef.current;
      accumulatedTimeRef.current = elapsed;
      setTime(elapsed);
      timerRef.current = window.requestAnimationFrame(updateTime);
    };
    
    timerRef.current = window.requestAnimationFrame(updateTime);
  };

  const pauseStopwatch = () => {
    if (!isRunning) return;
    setIsRunning(false);
    if (timerRef.current) {
      window.cancelAnimationFrame(timerRef.current);
      timerRef.current = null;
    }
  };

  const resetStopwatch = () => {
    setIsRunning(false);
    if (timerRef.current) {
      window.cancelAnimationFrame(timerRef.current);
      timerRef.current = null;
    }
    accumulatedTimeRef.current = 0;
    setTime(0);
    setLaps([]);
    lastLapTimeRef.current = 0;
  };

  const recordLap = () => {
    const totalTime = time;
    const previousLapsSum = lastLapTimeRef.current;
    const lapTime = totalTime - previousLapsSum;
    
    const newLap: Lap = {
      id: crypto.randomUUID(),
      lapNumber: laps.length + 1,
      lapTime: lapTime,
      splitTime: totalTime
    };

    lastLapTimeRef.current = totalTime;
    setLaps(prev => [newLap, ...prev]);
  };

  const formatTime = (timeMs: number): { hrs: string; mins: string; secs: string; ms: string } => {
    const hours = Math.floor(timeMs / 3600000);
    const minutes = Math.floor((timeMs % 3600000) / 60000);
    const seconds = Math.floor((timeMs % 60000) / 1000);
    const ms = Math.floor((timeMs % 1000) / 10); // Display 2 digits

    const pad = (n: number) => n.toString().padStart(2, '0');
    return {
      hrs: pad(hours),
      mins: pad(minutes),
      secs: pad(seconds),
      ms: pad(ms)
    };
  };

  const formattedTime = formatTime(time);

  // Identify Fastest and Slowest Lap
  const getLapStatus = (lapItem: Lap) => {
    if (laps.length < 2) return null;
    let minLap = laps[0];
    let maxLap = laps[0];

    laps.forEach(l => {
      if (l.lapTime < minLap.lapTime) minLap = l;
      if (l.lapTime > maxLap.lapTime) maxLap = l;
    });

    if (lapItem.id === minLap.id) return 'fastest';
    if (lapItem.id === maxLap.id) return 'slowest';
    return null;
  };

  // Stats calculation
  const totalLapsCount = laps.length;
  const avgLapTime = totalLapsCount > 0 
    ? laps.reduce((sum, l) => sum + l.lapTime, 0) / totalLapsCount 
    : 0;

  const handleCopyLaps = () => {
    if (laps.length === 0) return;
    const text = laps.map(l => {
      const lt = formatTime(l.lapTime);
      const st = formatTime(l.splitTime);
      return `Lap ${l.lapNumber} | Lap Time: ${lt.hrs > '00' ? lt.hrs + ':' : ''}${lt.mins}:${lt.secs}.${lt.ms} | Split: ${st.hrs > '00' ? st.hrs + ':' : ''}${st.mins}:${st.secs}.${st.ms}`;
    }).reverse().join('\n');

    navigator.clipboard.writeText(text);
    alert('Lap logs copied to clipboard successfully!');
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
      {/* Dynamic Main Stopwatch dial timer */}
      <div className="lg:col-span-12 flex flex-col items-center justify-center bg-neutral-950 border border-white/10 rounded-2xl p-8 shadow-2xl relative overflow-hidden">
        
        {/* Background decorative ring */}
        <div className="absolute w-96 h-96 border border-white/[0.02] rounded-full -top-12 -left-12 pointer-events-none" />

        <div className="flex gap-2 items-center mb-2 px-4 py-1.5 bg-[#141414] border border-white/5 rounded-full">
          <WatchIcon className="w-3.5 h-3.5 text-orange-brand" />
          <span className="text-[9px] font-mono tracking-widest font-black text-orange-brand uppercase">Swiss Precision Stopwatch</span>
        </div>

        {/* Large Time layout */}
        <div id="stopwatch-display" className="text-center font-mono my-8 select-none leading-none flex items-baseline tracking-tighter">
          {formattedTime.hrs !== '00' && (
            <>
              <span className="text-6xl sm:text-8xl font-black text-white">{formattedTime.hrs}</span>
              <span className="text-4xl sm:text-6xl font-black text-white/30 mx-1">:</span>
            </>
          )}
          <span className="text-6xl sm:text-8xl font-black text-white">{formattedTime.mins}</span>
          <span className="text-4xl sm:text-6xl font-black text-white/30 mx-1">:</span>
          <span className="text-6xl sm:text-8xl font-black text-white">{formattedTime.secs}</span>
          <span className="text-3xl sm:text-5xl font-extrabold text-orange-brand ml-2">.{formattedTime.ms}</span>
        </div>

        {/* Dial Control Actions */}
        <div className="flex items-center justify-center gap-3 w-full max-w-md mt-4 relative z-10">
          <button
            onClick={resetStopwatch}
            id="stopwatch-reset-btn"
            disabled={time === 0}
            className="flex-1 py-3 bg-[#111111] border border-white/10 hover:border-orange-brand/50 text-white/80 hover:text-white disabled:opacity-30 disabled:hover:border-white/10 disabled:hover:text-white/80 font-black text-xs uppercase tracking-widest rounded-lg transition-all cursor-pointer flex items-center justify-center gap-1.5"
          >
            <RotateCcw className="w-4 h-4" /> Reset
          </button>

          {isRunning ? (
            <button
              onClick={pauseStopwatch}
              id="stopwatch-pause-btn"
              className="flex-1 py-3 bg-white hover:bg-neutral-200 text-black font-black text-xs uppercase tracking-widest rounded-lg transition-all cursor-pointer flex items-center justify-center gap-1.5"
            >
              <Pause className="w-4 h-4" /> Pause
            </button>
          ) : (
            <button
              onClick={startStopwatch}
              id="stopwatch-start-btn"
              className="flex-1 py-3 bg-orange-brand hover:bg-[#D96B1E] text-black font-black text-xs uppercase tracking-widest rounded-lg transition-all cursor-pointer flex items-center justify-center gap-1.5 shadow-[0_4px_12px_rgba(242,125,38,0.25)]"
            >
              <Play className="w-4 h-4 fill-black stroke-black" /> Begin
            </button>
          )}

          <button
            onClick={recordLap}
            id="stopwatch-lap-btn"
            disabled={!isRunning}
            className="flex-1 py-3 bg-[#111111] border border-white/10 hover:border-white/30 text-white/80 disabled:opacity-30 disabled:hover:border-white/10 font-black text-xs uppercase tracking-widest rounded-lg transition-all cursor-pointer flex items-center justify-center gap-1.5"
          >
            <Award className="w-4 h-4" /> Log Lap
          </button>
        </div>
      </div>

      {/* Lap Stats & Lap Listings split columns */}
      {laps.length > 0 && (
        <div className="lg:col-span-12 grid grid-cols-1 md:grid-cols-12 gap-6 w-full">
          {/* Quick Average Statistics Panel */}
          <div className="md:col-span-4 bg-neutral-950 border border-white/10 rounded-2xl p-5 shadow-xl space-y-4">
            <h4 className="text-[10px] font-mono font-bold text-white/40 uppercase tracking-widest flex items-center gap-1.5">
              <ListFilter className="w-3.5 h-3.5 text-orange-brand" /> CALIBRATION ANALYTICS
            </h4>
            
            <div className="space-y-3">
              <div className="bg-[#121212] p-4 rounded-xl border border-white/5">
                <span className="text-[9px] text-white/40 font-mono block uppercase tracking-wider">Total Splits Registered</span>
                <span className="text-2xl font-black text-white">{totalLapsCount}</span>
              </div>

              <div className="bg-[#121212] p-4 rounded-xl border border-white/5">
                <span className="text-[9px] text-white/40 font-mono block uppercase tracking-wider">Mean Lap Duration</span>
                <span className="text-2xl font-mono font-black text-orange-brand">
                  {(() => {
                    const av = formatTime(avgLapTime);
                    return `${av.hrs > '00' ? av.hrs + ':' : ''}${av.mins}:${av.secs}.${av.ms}`;
                  })()}
                </span>
              </div>
            </div>

            <button
              onClick={handleCopyLaps}
              className="w-full flex items-center justify-center gap-1.5 py-3 border border-white/10 text-white/70 hover:text-white hover:bg-white/5 rounded-lg text-xs font-black uppercase tracking-widest transition-all cursor-pointer"
            >
              <Clipboard className="w-3.5 h-3.5" /> Export Lap Data
            </button>
          </div>

          {/* Core Table Lap logs listing */}
          <div className="md:col-span-8 bg-neutral-950 border border-white/10 rounded-2xl p-5 shadow-xl">
            <div className="flex justify-between items-center mb-3">
              <h4 className="text-[10px] font-mono font-bold text-white/40 uppercase tracking-widest">LAP SYSTEM SEQUENCE</h4>
              <span className="text-[9px] font-mono text-white/40 uppercase tracking-wider">Newest First</span>
            </div>

            <div className="max-h-60 overflow-y-auto border border-white/5 rounded-xl divide-y divide-white/5 pr-1">
              {laps.map(lap => {
                const lpTimeParsed = formatTime(lap.lapTime);
                const spTimeParsed = formatTime(lap.splitTime);
                const status = getLapStatus(lap);

                return (
                  <div key={lap.id} className="flex items-center justify-between p-4 hover:bg-white/[0.02] transition-colors text-xs font-semibold">
                    <div className="flex items-center gap-3">
                      <span className="text-white/40 font-mono text-[10px]">INDEX_0{lap.lapNumber}</span>
                      {status === 'fastest' && (
                        <span className="px-2 py-0.5 rounded bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 text-[8px] uppercase font-bold tracking-widest">
                          🏎️ FASTEST
                        </span>
                      )}
                      {status === 'slowest' && (
                        <span className="px-2 py-0.5 rounded bg-red-500/10 text-red-500 border border-red-500/20 text-[8px] uppercase font-bold tracking-widest">
                          🐢 SLOWEST
                        </span>
                      )}
                    </div>
                    
                    <div className="flex items-center gap-8 font-mono">
                      <div>
                        <span className="text-[9px] text-white/40 font-mono block text-right uppercase tracking-wider">Lap Segment</span>
                        <span className={`text-sm ${status === 'fastest' ? 'text-emerald-400 font-black' : status === 'slowest' ? 'text-red-400' : 'text-white font-bold'}`}>
                          {lpTimeParsed.hrs !== '00' && `${lpTimeParsed.hrs}:`}
                          {lpTimeParsed.mins}:{lpTimeParsed.secs}
                          <span className="text-[10px] opacity-70">.{lpTimeParsed.ms}</span>
                        </span>
                      </div>
                      <div className="text-right">
                        <span className="text-[9px] text-white/40 font-mono block uppercase tracking-wider">Cumulative</span>
                        <span className="text-white/60">
                          {spTimeParsed.hrs !== '00' && `${spTimeParsed.hrs}:`}
                          {spTimeParsed.mins}:{spTimeParsed.secs}
                          <span className="text-[10px]">.{spTimeParsed.ms}</span>
                        </span>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
