import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Play, Pause, RotateCcw, Trash2, Plus, Volume2, BellOff, Hourglass, Settings, Sparkles } from 'lucide-react';
import { Timer } from '../types';
import { playSound, stopSound, SOUND_TYPES } from '../lib/audio';

interface TimerTabProps {
  timers: Timer[];
  setTimers: React.Dispatch<React.SetStateAction<Timer[]>>;
}

export default function TimerTab({ timers, setTimers }: TimerTabProps) {
  // Form values
  const [hours, setHours] = useState<number>(0);
  const [minutes, setMinutes] = useState<number>(5);
  const [seconds, setSeconds] = useState<number>(0);
  const [label, setLabel] = useState<string>('');
  const [selectedSound, setSelectedSound] = useState<string>('classic_beep');
  
  // Preview audio state
  const [previewingId, setPreviewingId] = useState<string | null>(null);

  // Stop any previews on unmount
  useEffect(() => {
    return () => {
      stopSound('preview');
    };
  }, []);

  const handlePreviewSound = (soundType: string) => {
    if (previewingId === soundType) {
      stopSound('preview');
      setPreviewingId(null);
    } else {
      stopSound('preview');
      setPreviewingId(soundType);
      playSound(soundType, 'preview', false);
      // Automatically stop preview after 2.5 seconds
      setTimeout(() => {
        setPreviewingId(prev => prev === soundType ? null : prev);
      }, 2500);
    }
  };

  const addTimer = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    
    const totalSecs = hours * 3600 + minutes * 60 + seconds;
    if (totalSecs <= 0) return;

    const newTimer: Timer = {
      id: crypto.randomUUID(),
      label: label.trim() || `Timer (${formatDuration(totalSecs)})`,
      totalDuration: totalSecs,
      remainingTime: totalSecs,
      isRunning: false,
      isCompleted: false,
      soundType: selectedSound,
      createdAt: Date.now()
    };

    setTimers(prev => [newTimer, ...prev]);
    // Reset form
    setLabel('');
    // Leave hours/minutes/seconds as is for lazy reuse
  };

  const addPreset = (labelPreset: string, durationSecs: number) => {
    const newTimer: Timer = {
      id: crypto.randomUUID(),
      label: labelPreset,
      totalDuration: durationSecs,
      remainingTime: durationSecs,
      isRunning: false,
      isCompleted: false,
      soundType: selectedSound,
      createdAt: Date.now()
    };
    setTimers(prev => [newTimer, ...prev]);
  };

  const toggleTimer = (id: string) => {
    setTimers(prev => prev.map(t => {
      if (t.id === id) {
        // If it was completed, reset and start
        if (t.isCompleted) {
          stopSound(t.id);
          return { ...t, remainingTime: t.totalDuration, isRunning: true, isCompleted: false };
        }
        return { ...t, isRunning: !t.isRunning };
      }
      return t;
    }));
  };

  const resetTimer = (id: string) => {
    stopSound(id);
    setTimers(prev => prev.map(t => {
      if (t.id === id) {
        return { ...t, remainingTime: t.totalDuration, isRunning: false, isCompleted: false };
      }
      return t;
    }));
  };

  const deleteTimer = (id: string) => {
    stopSound(id);
    setTimers(prev => prev.filter(t => t.id !== id));
  };

  const stopTimerRing = (id: string) => {
    stopSound(id);
    setTimers(prev => prev.map(t => {
      if (t.id === id) {
        return { ...t, isCompleted: false, isRunning: false, remainingTime: t.totalDuration };
      }
      return t;
    }));
  };

  function formatDuration(totalSeconds: number): string {
    const h = Math.floor(totalSeconds / 3600);
    const m = Math.floor((totalSeconds % 3600) / 60);
    const s = totalSeconds % 60;
    
    if (h > 0) {
      return `${h}h ${m}m ${s}s`;
    }
    if (m > 0) {
      return `${m}m ${s}s`;
    }
    return `${s}s`;
  }

  function formatTime(totalSeconds: number): string {
    const h = Math.floor(totalSeconds / 3600);
    const m = Math.floor((totalSeconds % 3600) / 60);
    const s = totalSeconds % 60;
    
    const pad = (n: number) => n.toString().padStart(2, '0');
    return `${h > 0 ? pad(h) + ':' : ''}${pad(m)}:${pad(s)}`;
  }

  const quickPresets = [
    { name: '1 Min', secs: 60 },
    { name: '3 Min', secs: 180 },
    { name: '5 Min', secs: 300 },
    { name: '10 Min', secs: 600 },
    { name: '15 Min', secs: 900 },
    { name: '25 Min', secs: 1500 },
    { name: '30 Min', secs: 1800 },
    { name: '1 Hour', secs: 3600 },
  ];

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
      {/* Timer Creator Configuration */}
      <div id="timer-creator-card" className="lg:col-span-5 bg-neutral-950 border border-white/10 rounded-2xl p-6 shadow-xl relative overflow-hidden">
        
        <div className="flex items-center gap-3 mb-6">
          <div className="p-3 bg-[#1A1A1A] rounded-xl text-orange-brand">
            <Hourglass className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-sm font-black text-white uppercase tracking-wider">Create Timer</h2>
            <p className="text-[10px] text-white/40 tracking-wide font-mono uppercase">Countdown calibration</p>
          </div>
        </div>

        <form onSubmit={addTimer} className="space-y-6">
          {/* Quick presets list */}
          <div>
            <label className="text-[10px] font-bold text-white/40 uppercase tracking-widest block mb-3 font-mono">Quick Preset Durations</label>
            <div className="grid grid-cols-4 gap-2">
              {quickPresets.map(preset => (
                <button
                  key={preset.name}
                  type="button"
                  id={`preset-${preset.name.replace(' ', '-').toLowerCase()}`}
                  onClick={() => addPreset(preset.name, preset.secs)}
                  className="px-2 py-2.5 text-xs font-black text-white bg-[#141414] hover:bg-neutral-900 border border-white/5 hover:border-orange-brand/35 rounded-lg transition-all text-center cursor-pointer uppercase tracking-tighter"
                >
                  {preset.name}
                </button>
              ))}
            </div>
          </div>

          <div className="border-b border-white/5 my-2"></div>

          {/* Time Picker Dial Inputs */}
          <div>
            <label className="text-[10px] font-bold text-white/40 uppercase tracking-widest block mb-3 font-mono">Set Custom Duration</label>
            <div className="grid grid-cols-3 gap-3 bg-[#121212] p-4 rounded-xl border border-white/5">
              <div className="text-center">
                <span className="text-[10px] text-white/40 font-mono block mb-1 uppercase">Hours</span>
                <input
                  type="number"
                  min="0"
                  max="23"
                  value={hours}
                  onChange={e => setHours(Math.max(0, parseInt(e.target.value) || 0))}
                  className="w-full text-center text-2xl font-black bg-neutral-950 border border-white/10 rounded-lg py-2 text-white focus:outline-none focus:ring-1 focus:ring-orange-brand focus:border-orange-brand"
                />
              </div>
              <div className="text-center">
                <span className="text-[10px] text-white/40 font-mono block mb-1 uppercase">Minutes</span>
                <input
                  type="number"
                  min="0"
                  max="59"
                  value={minutes}
                  onChange={e => setMinutes(Math.max(0, Math.min(59, parseInt(e.target.value) || 0)))}
                  className="w-full text-center text-2xl font-black bg-neutral-950 border border-white/10 rounded-lg py-2 text-white focus:outline-none focus:ring-1 focus:ring-orange-brand focus:border-orange-brand"
                />
              </div>
              <div className="text-center">
                <span className="text-[10px] text-white/40 font-mono block mb-1 uppercase">Seconds</span>
                <input
                  type="number"
                  min="0"
                  max="59"
                  value={seconds}
                  onChange={e => setSeconds(Math.max(0, Math.min(59, parseInt(e.target.value) || 0)))}
                  className="w-full text-center text-2xl font-black bg-neutral-950 border border-white/10 rounded-lg py-2 text-white focus:outline-none focus:ring-1 focus:ring-orange-brand focus:border-orange-brand"
                />
              </div>
            </div>
          </div>

          {/* Label input */}
          <div>
            <label className="text-[10px] font-bold text-white/40 uppercase tracking-widest block mb-2 font-mono">Timer Tag / Label</label>
            <input
              type="text"
              id="timer-label-input"
              value={label}
              onChange={e => setLabel(e.target.value)}
              placeholder="e.g. Pasta Boiling, Quick Rest"
              maxLength={40}
              className="w-full px-4 py-3 bg-[#121212] text-xs font-semibold uppercase tracking-wider border border-white/10 rounded-lg text-white placeholder-white/20 focus:outline-none focus:ring-1 focus:ring-orange-brand focus:border-orange-brand"
            />
          </div>

          {/* Alert Ring Tone Selector */}
          <div>
            <label className="text-[10px] font-bold text-white/40 uppercase tracking-widest block mb-2 font-mono">Alert Audio Sound</label>
            <div className="space-y-1.5 max-h-40 overflow-y-auto pr-1">
              {SOUND_TYPES.map(sound => (
                <div
                  key={sound.id}
                  className={`flex items-center justify-between p-2.5 rounded-lg border ${
                    selectedSound === sound.id
                      ? 'bg-orange-brand border-orange-brand text-black font-extrabold'
                      : 'bg-neutral-900/50 border-white/5 hover:bg-neutral-900 text-white/80'
                  } transition-all`}
                >
                  <label className="flex items-center gap-2.5 cursor-pointer flex-1 py-1 text-[11px] font-black uppercase tracking-wider">
                    <input
                      type="radio"
                      name="timer-sound"
                      checked={selectedSound === sound.id}
                      onChange={() => setSelectedSound(sound.id)}
                      className="sr-only"
                    />
                    <div className={`w-3.5 h-3.5 rounded-full border-2 flex items-center justify-center ${selectedSound === sound.id ? 'border-black' : 'border-neutral-700'}`}>
                      {selectedSound === sound.id && <div className="w-1.5 h-1.5 rounded-full bg-black" />}
                    </div>
                    {sound.name}
                  </label>
                  <button
                    type="button"
                    onClick={() => handlePreviewSound(sound.id)}
                    className={`p-1.5 rounded-md border hover:scale-105 transition-all cursor-pointer ${
                      selectedSound === sound.id
                        ? 'bg-black/10 border-black/20 text-black'
                        : 'bg-neutral-950 border-white/5 text-white/60 hover:text-white'
                    }`}
                  >
                    <Volume2 className={`w-3.5 h-3.5 ${previewingId === sound.id ? 'animate-bounce text-red-500' : ''}`} />
                  </button>
                </div>
              ))}
            </div>
          </div>

          <button
            type="submit"
            id="start-timer-btn"
            className="w-full flex items-center justify-center gap-2 py-3.5 bg-orange-brand hover:bg-[#D96B1E] text-black text-xs font-black rounded-lg uppercase tracking-widest transition-all cursor-pointer shadow-[0_4px_10px_rgba(242,125,38,0.25)]"
          >
            <Plus className="w-4 h-4 text-black stroke-[3px]" /> Start Countdown
          </button>
        </form>
      </div>

      {/* Active Running Timers Panel */}
      <div className="lg:col-span-7 space-y-4">
        <div className="flex items-center justify-between pb-2 border-b border-white/5">
          <h3 className="text-[10px] font-mono font-bold text-white/40 uppercase tracking-widest">
            ACTIVE SYSTEMS ({timers.length})
          </h3>
          {timers.length > 0 && (
            <button
              onClick={() => {
                timers.forEach(t => stopSound(t.id));
                setTimers([]);
              }}
              className="text-[10px] font-mono font-bold text-white/40 hover:text-orange-brand transition-colors flex items-center gap-1.5 cursor-pointer uppercase tracking-widest"
            >
              <Trash2 className="w-3.5 h-3.5" /> Purge All
            </button>
          )}
        </div>

        <AnimatePresence mode="popLayout">
          {timers.length === 0 ? (
            <motion.div
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              className="bg-neutral-950 border border-dashed border-white/10 rounded-2xl p-12 text-center"
            >
              <div className="inline-flex items-center justify-center p-4 bg-[#141414] rounded-xl border border-white/5 text-white/30 mb-4 animate-pulse">
                <Hourglass className="w-6 h-6 text-orange-brand" />
              </div>
              <h4 className="text-xs font-black uppercase tracking-widest text-white mb-1">Grid System Calibrated</h4>
              <p className="text-[10px] font-mono text-white/40 max-w-xs mx-auto uppercase tracking-wide">
                Configure presets or create manual calibration cycles on the telemetry form.
              </p>
            </motion.div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {timers.map(timer => {
                const percent = (timer.remainingTime / timer.totalDuration) * 100;
                const alarmSoundObj = SOUND_TYPES.find(s => s.id === timer.soundType);

                return (
                  <motion.div
                    key={timer.id}
                    id={`active-timer-${timer.id}`}
                    layout
                    initial={{ opacity: 0, scale: 0.95 }}
                    animate={{ opacity: 1, scale: 1 }}
                    exit={{ opacity: 0, scale: 0.9 }}
                    className={`relative overflow-hidden bg-neutral-950 border rounded-xl p-5 shadow-xl transition-all duration-300 ${
                      timer.isCompleted 
                        ? 'border-orange-brand/80 shadow-[0_0_30px_rgba(242,125,38,0.15)] bg-orange-brand/[0.04]' 
                        : 'border-white/10 hover:border-white/20'
                    }`}
                  >
                    {/* Ringing flashing overlay background */}
                    {timer.isCompleted && (
                      <div className="absolute inset-0 bg-orange-brand/5 animate-pulse pointer-events-none" />
                    )}

                    <div className="flex justify-between items-start gap-2 mb-3">
                      <div className="min-w-0">
                        <h4 className="font-extrabold text-white text-xs uppercase tracking-wider truncate">{timer.label}</h4>
                        <p className="text-[9px] text-white/40 font-mono uppercase tracking-widest">
                          Tone: {alarmSoundObj?.name || 'Digital Beep'}
                        </p>
                      </div>
                      <button
                        onClick={() => deleteTimer(timer.id)}
                        className="text-white/40 hover:text-red-500 p-1 rounded-md hover:bg-white/5 transition-colors cursor-pointer"
                        title="Delete Timer"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>

                    {/* Numeric Countdown Display */}
                    <div className="flex items-baseline gap-2 mb-4">
                      <span className={`text-4xl font-extrabold font-mono tracking-tighter ${
                        timer.isCompleted 
                          ? 'text-orange-brand animate-ping text-5xl font-black' 
                          : timer.isRunning 
                            ? 'text-white' 
                            : 'text-white/40'
                      }`}>
                        {formatTime(timer.remainingTime)}
                      </span>
                      {timer.isCompleted && (
                        <span className="text-[9px] font-mono font-bold uppercase text-orange-brand animate-pulse tracking-widest flex items-center gap-0.5">
                          <Sparkles className="w-3 h-3 text-orange-brand" /> RINGING
                        </span>
                      )}
                    </div>

                    {/* Custom progress indicators */}
                    <div className="w-full bg-[#111111] rounded-full h-1 overflow-hidden mb-5">
                      <div
                        className={`h-full transition-all duration-1000 ${
                          timer.isCompleted 
                            ? 'bg-orange-brand w-full' 
                            : 'bg-orange-brand'
                        }`}
                        style={{ width: `${percent}%` }}
                      />
                    </div>

                    {/* Action Panel */}
                    <div className="flex items-center gap-2">
                      {timer.isCompleted ? (
                        <button
                          onClick={() => stopTimerRing(timer.id)}
                          className="flex-1 py-2 bg-orange-brand hover:bg-[#D96B1E] text-black font-black uppercase tracking-wider rounded-md text-[10px] flex items-center justify-center gap-1.5 transition-all shadow-[0_4px_10px_rgba(242,125,38,0.2)] cursor-pointer"
                        >
                          <BellOff className="w-3.5 h-3.5 text-black stroke-[3px]" /> Stop Alert
                        </button>
                      ) : (
                        <>
                          <button
                            onClick={() => toggleTimer(timer.id)}
                            className={`flex-1 py-1.5 rounded-md font-bold uppercase tracking-widest text-[9px] flex items-center justify-center gap-1 transition-all cursor-pointer ${
                              timer.isRunning
                                ? 'bg-white/10 text-white hover:bg-white/20'
                                : 'bg-orange-brand text-black hover:bg-[#D96B1E]'
                            }`}
                          >
                            {timer.isRunning ? (
                              <>
                                <Pause className="w-3.5 h-3.5" /> Pause
                              </>
                            ) : (
                              <>
                                <Play className="w-3.5 h-3.5" /> Initiate
                              </>
                            )}
                          </button>
                          <button
                            onClick={() => resetTimer(timer.id)}
                            className="p-1.5 border border-white/10 rounded-md text-white/60 hover:text-white hover:bg-white/5 transition-all cursor-pointer"
                            title="Reset Timer"
                          >
                            <RotateCcw className="w-3.5 h-3.5" />
                          </button>
                        </>
                      )}
                    </div>
                  </motion.div>
                );
              })}
            </div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}
