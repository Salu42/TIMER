import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Globe, Plus, Trash2, Shield, Compass, Navigation } from 'lucide-react';
import { WorldClockItem } from '../types';

interface WorldClockTabProps {
  worldClocks: WorldClockItem[];
  setWorldClocks: React.Dispatch<React.SetStateAction<WorldClockItem[]>>;
}

const PRESET_CITIES = [
  { cityName: 'New York', timezone: 'America/New_York' },
  { cityName: 'London', timezone: 'Europe/London' },
  { cityName: 'Paris', timezone: 'Europe/Paris' },
  { cityName: 'Geneva', timezone: 'Europe/Zurich' },
  { cityName: 'Tokyo', timezone: 'Asia/Tokyo' },
  { cityName: 'Singapore', timezone: 'Asia/Singapore' },
  { cityName: 'Dubai', timezone: 'Asia/Dubai' },
  { cityName: 'Sydney', timezone: 'Australia/Sydney' },
  { cityName: 'Mumbai', timezone: 'Asia/Kolkata' },
  { cityName: 'Cape Town', timezone: 'Africa/Johannesburg' },
];

export default function WorldClockTab({ worldClocks, setWorldClocks }: WorldClockTabProps) {
  const [selectedPreset, setSelectedPreset] = useState<string>('America/New_York');
  const [customCityName, setCustomCityName] = useState<string>('');
  const [customTimezone, setCustomTimezone] = useState<string>('America/New_York');
  
  const [currentTime, setCurrentTime] = useState<Date>(new Date());

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentTime(new Date());
    }, 1000);
    return () => clearInterval(interval);
  }, []);

  const addWorldClock = (e: React.FormEvent) => {
    e.preventDefault();
    
    // Determine title & tz
    const preset = PRESET_CITIES.find(p => p.timezone === selectedPreset);
    const cityName = customCityName.trim() || preset?.cityName || 'Unknown';
    const tz = preset?.timezone || customTimezone;

    // Check if duplicate tz
    if (worldClocks.some(w => w.timezone === tz)) {
      alert('This timezone has already been added to your dashboard!');
      return;
    }

    const newItem: WorldClockItem = {
      id: crypto.randomUUID(),
      cityName,
      timezone: tz
    };

    setWorldClocks(prev => [...prev, newItem]);
    
    // Reset form overrides
    setCustomCityName('');
  };

  const deleteClock = (id: string) => {
    setWorldClocks(prev => prev.filter(w => w.id !== id));
  };

  const formatTimeForZone = (date: Date, tz: string) => {
    return date.toLocaleTimeString(undefined, {
      timeZone: tz,
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit',
      hour12: true
    });
  };

  const formatDateForZone = (date: Date, tz: string) => {
    return date.toLocaleDateString(undefined, {
      timeZone: tz,
      weekday: 'short',
      month: 'short',
      day: 'numeric'
    });
  };

  const getOffsetString = (tz: string) => {
    try {
      // Find offset in minutes
      const date = new Date();
      const localString = date.toLocaleString('en-US', { timeZone: tz });
      const tzDate = new Date(localString);
      const diffMs = tzDate.getTime() - date.getTime();
      const diffHours = Math.round(diffMs / (1000 * 60 * 60));

      if (diffHours === 0) return 'Same as local';
      return diffHours > 0 ? `+${diffHours}h ahead` : `${diffHours}h behind`;
    } catch {
      return '';
    }
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
      {/* World Clock Add Configurator */}
      <div id="world-clock-creator-card" className="lg:col-span-12 xl:col-span-5 bg-neutral-950 border border-white/10 rounded-2xl p-6 shadow-xl leading-none">
        <div className="flex items-center gap-3 mb-6">
          <div className="p-3 bg-[#1A1A1A] rounded-xl text-orange-brand">
            <Globe className="w-5 h-5 animate-pulse" />
          </div>
          <div>
            <h2 className="text-sm font-black text-white uppercase tracking-wider">World Tickers</h2>
            <p className="text-[10px] text-white/40 tracking-wide font-mono uppercase">Global offset vectors</p>
          </div>
        </div>

        <form onSubmit={addWorldClock} className="space-y-5">
          <div>
            <label className="text-[10px] font-bold text-white/40 uppercase tracking-widest block mb-2 font-mono">Preset City Selector</label>
            <select
              id="preset-city-select"
              value={selectedPreset}
              onChange={e => {
                setSelectedPreset(e.target.value);
                const city = PRESET_CITIES.find(p => p.timezone === e.target.value);
                if (city) setCustomCityName(city.cityName);
              }}
              className="w-full px-4 py-3 bg-[#121212] text-xs font-black uppercase tracking-wider border border-white/10 rounded-lg text-white focus:outline-none focus:ring-1 focus:ring-orange-brand cursor-pointer"
            >
              {PRESET_CITIES.map(preset => (
                <option key={preset.timezone} value={preset.timezone} className="bg-neutral-950 text-white">
                  {preset.cityName} ({preset.timezone})
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="text-[10px] font-bold text-white/40 uppercase tracking-widest block mb-2 font-mono">Custom Rename Label (Optional)</label>
            <input
              type="text"
              id="custom-city-name-input"
              value={customCityName}
              onChange={e => setCustomCityName(e.target.value)}
              placeholder="e.g. My Switzerland HQ"
              maxLength={25}
              className="w-full px-4 py-3 bg-[#121212] text-xs font-semibold uppercase tracking-wider border border-white/10 rounded-lg text-white placeholder-white/20 focus:outline-none focus:ring-1 focus:ring-orange-brand"
            />
          </div>

          <button
            type="submit"
            id="add-world-clock-btn"
            className="w-full flex items-center justify-center gap-2 py-3.5 bg-orange-brand hover:bg-[#D96B1E] text-black text-xs font-black rounded-lg uppercase tracking-widest transition-all cursor-pointer shadow-[0_4px_10px_rgba(242,125,38,0.25)]"
          >
            <Plus className="w-4 h-4 text-black stroke-[3px]" /> Add Tracking Clock
          </button>
        </form>
      </div>

      {/* World Clock Grid Lists */}
      <div className="lg:col-span-12 xl:col-span-7 space-y-4">
        {/* Massive Main Local Time Banner Container */}
        <div className="p-6 bg-neutral-950 text-white rounded-2xl text-center space-y-2 relative overflow-hidden shadow-xl border border-white/10">
          <div className="absolute right-3 top-3 px-2 py-0.5 bg-orange-brand/10 text-orange-brand border border-orange-brand/20 rounded text-[8px] uppercase tracking-wider font-bold">
            Local Browser Time
          </div>

          <div className="flex justify-center items-center gap-1.5 text-orange-brand mb-1">
            <Compass className="w-3.5 h-3.5" />
            <span className="text-[10px] uppercase font-bold tracking-wider">Your Position</span>
          </div>

          <h3 className="text-4xl sm:text-5xl font-black font-mono tracking-tighter">
            {currentTime.toLocaleTimeString(undefined, {
              hour: '2-digit',
              minute: '2-digit',
              second: '2-digit',
              hour12: true
            })}
          </h3>
          <p className="text-[10px] font-mono text-white/40 uppercase tracking-widest">
            {currentTime.toLocaleDateString(undefined, {
              weekday: 'long',
              year: 'numeric',
              month: 'long',
              day: 'numeric'
            })}
          </p>
        </div>

        <h3 className="text-[10px] font-mono font-bold text-white/40 uppercase tracking-widest pb-2 border-b border-white/5">
          TRACKED GLOBAL CITIES ({worldClocks.length})
        </h3>

        <AnimatePresence mode="popLayout">
          {worldClocks.length === 0 ? (
            <motion.div
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              className="bg-neutral-950 border border-dashed border-white/10 rounded-2xl p-12 text-center"
            >
              <div className="inline-flex items-center justify-center p-4 bg-[#141414] rounded-xl border border-white/5 text-white/30 mb-4">
                <Globe className="w-6 h-6 text-orange-brand animate-spin-slow" />
              </div>
              <h4 className="text-xs font-black uppercase tracking-widest text-white mb-1">No Timezones Registered</h4>
              <p className="text-[10px] font-mono text-white/40 max-w-xs mx-auto uppercase tracking-wide">
                Include preset capitals or customized corporate regional meridians to initiate telemetry offsets.
              </p>
            </motion.div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {worldClocks.map(clock => (
                <motion.div
                  key={clock.id}
                  id={`world-clock-${clock.id}`}
                  layout
                  initial={{ opacity: 0, scale: 0.95 }}
                  animate={{ opacity: 1, scale: 1 }}
                  exit={{ opacity: 0, scale: 0.9 }}
                  className="bg-neutral-950 border border-white/10 hover:border-white/20 rounded-xl p-5 shadow-xl transition-all duration-300 flex flex-col justify-between"
                >
                  <div className="flex justify-between items-start gap-4 mb-3">
                    <div>
                      <h4 className="font-black text-white text-sm uppercase tracking-wider truncate leading-tight">
                        {clock.cityName}
                      </h4>
                      <p className="text-[9px] font-mono text-orange-brand mt-0.5 truncate max-w-[150px] uppercase">
                        {clock.timezone}
                      </p>
                    </div>
                    <button
                      onClick={() => deleteClock(clock.id)}
                      className="text-white/40 hover:text-red-500 p-1.5 rounded-md hover:bg-white/5 transition-colors cursor-pointer"
                      title="Remove Clock"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>

                  <div className="space-y-2 mt-4">
                    <h3 className="text-2xl font-black font-mono tracking-tight text-white/90">
                      {formatTimeForZone(currentTime, clock.timezone)}
                    </h3>

                    <div className="flex items-center justify-between text-[9px] font-mono font-bold text-white/40 uppercase">
                      <span>{formatDateForZone(currentTime, clock.timezone)}</span>
                      <span className="bg-white/5 border border-white/10 text-white px-2 py-0.5 rounded text-[8px]">
                        {getOffsetString(clock.timezone)}
                      </span>
                    </div>
                  </div>
                </motion.div>
              ))}
            </div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}
