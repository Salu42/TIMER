import { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Play, Pause, RotateCcw, Award, Zap, Heart, RefreshCw, Trash2, Dumbbell } from 'lucide-react';
import { IntervalProfile } from '../types';
import { playSound } from '../lib/audio';

type Phase = 'idle' | 'prep' | 'work' | 'rest' | 'cooldown' | 'done';

export default function IntervalTab() {
  const [prepTime, setPrepTime] = useState<number>(5);
  const [workTime, setWorkTime] = useState<number>(30);
  const [restTime, setRestTime] = useState<number>(10);
  const [cycles, setCycles] = useState<number>(4);
  const [sets, setSets] = useState<number>(1);
  const [cooldownTime, setCooldownTime] = useState<number>(10);

  // Active state
  const [phase, setPhase] = useState<Phase>('idle');
  const [currentSet, setCurrentSet] = useState<number>(1);
  const [currentCycle, setCurrentCycle] = useState<number>(1);
  const [timeLeft, setTimeLeft] = useState<number>(0);
  const [totalDuration, setTotalDuration] = useState<number>(0);
  const [isRunning, setIsRunning] = useState<boolean>(false);

  const timerRef = useRef<number | null>(null);

  // Stop active tickers
  useEffect(() => {
    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, []);

  const startSession = () => {
    if (phase !== 'idle' && phase !== 'done') {
      setIsRunning(true);
      return;
    }

    setPhase('prep');
    setTimeLeft(prepTime);
    setTotalDuration(prepTime);
    setCurrentSet(1);
    setCurrentCycle(1);
    setIsRunning(true);
    playSound('chime', 'interval', false);
  };

  const pauseSession = () => {
    setIsRunning(false);
  };

  const resetSession = () => {
    setIsRunning(false);
    setPhase('idle');
    setTimeLeft(0);
    setCurrentCycle(1);
    setCurrentSet(1);
    if (timerRef.current) {
      clearInterval(timerRef.current);
      timerRef.current = null;
    }
  };

  // State loop controller triggered every second
  useEffect(() => {
    if (!isRunning) {
      if (timerRef.current) {
        clearInterval(timerRef.current);
        timerRef.current = null;
      }
      return;
    }

    timerRef.current = window.setInterval(() => {
      setTimeLeft(prev => {
        if (prev <= 1) {
          // Progress to the next phase
          triggerNextPhase();
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, [isRunning, phase, currentCycle, currentSet, prepTime, workTime, restTime, cycles, sets, cooldownTime]);

  const triggerNextPhase = () => {
    if (phase === 'prep') {
      // Go to first Work cycle
      setPhase('work');
      setTimeLeft(workTime);
      setTotalDuration(workTime);
      playSound('classic_beep', 'interval', false);
    } else if (phase === 'work') {
      // Check if there's rest needed
      if (currentCycle < cycles) {
        setPhase('rest');
        setTimeLeft(restTime);
        setTotalDuration(restTime);
        playSound('marimba', 'interval', false);
      } else {
        // Completed cycles for this set
        if (currentSet < sets) {
          // Proceed to next set with a Rest period first
          setPhase('rest');
          setTimeLeft(restTime);
          setTotalDuration(restTime);
          setCurrentSet(prev => prev + 1);
          setCurrentCycle(1);
          playSound('marimba', 'interval', false);
        } else {
          // All sets completed. Go to Cooldown
          if (cooldownTime > 0) {
            setPhase('cooldown');
            setTimeLeft(cooldownTime);
            setTotalDuration(cooldownTime);
            playSound('chime', 'interval', false);
          } else {
            finishSession();
          }
        }
      }
    } else if (phase === 'rest') {
      // Rest is over, start next cycle work
      if (phase === 'rest' && currentCycle < cycles) {
        setCurrentCycle(prev => prev + 1);
      }
      setPhase('work');
      setTimeLeft(workTime);
      setTotalDuration(workTime);
      playSound('classic_beep', 'interval', false);
    } else if (phase === 'cooldown') {
      finishSession();
    }
  };

  const finishSession = () => {
    setIsRunning(false);
    setPhase('done');
    setTimeLeft(0);
    playSound('zen_gong', 'interval', false);
  };

  const percent = timeLeft > 0 ? (timeLeft / totalDuration) * 100 : 0;

  const getPhaseColor = () => {
    switch (phase) {
      case 'prep': return 'bg-amber-500/15 border-amber-500/30 text-amber-400';
      case 'work': return 'bg-rose-500/15 border-rose-500/30 text-rose-400';
      case 'rest': return 'bg-emerald-500/15 border-emerald-500/30 text-emerald-400';
      case 'cooldown': return 'bg-indigo-500/15 border-indigo-500/30 text-indigo-100';
      case 'done': return 'bg-orange-brand/10 border-orange-brand/30 text-orange-brand';
      default: return 'bg-[#121212] border-white/5 text-white';
    }
  };

  const getPhaseName = () => {
    switch (phase) {
      case 'prep': return 'Saccade Get Ready';
      case 'work': return 'WORK PHASE ACTIVE';
      case 'rest': return 'REST SEQUENCE';
      case 'cooldown': return 'COOL DOWN STAGE';
      case 'done': return 'SESSION COMPLETED';
      default: return 'Configure Calibration';
    }
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
      {/* Interval Form Inputs */}
      <div id="interval-creator-card" className="lg:col-span-12 xl:col-span-5 bg-neutral-950 border border-white/10 rounded-2xl p-6 shadow-xl space-y-4">
        
        <div className="flex items-center gap-3 mb-6">
          <div className="p-3 bg-[#1A1A1A] rounded-xl text-orange-brand">
            <Dumbbell className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-sm font-black text-white uppercase tracking-wider">Interval Timer</h2>
            <p className="text-[10px] text-white/40 tracking-wide font-mono uppercase">Circuit & HIIT loops</p>
          </div>
        </div>

        {phase === 'idle' || phase === 'done' ? (
          <div className="grid grid-cols-2 gap-3.5">
            <div className="bg-[#121212] p-3 rounded-lg border border-white/5">
              <label className="text-[9px] uppercase font-bold text-white/40 block mb-1 font-mono tracking-wider">Prep Period (s)</label>
              <input
                type="number"
                min="0"
                value={prepTime}
                onChange={e => setPrepTime(Math.max(0, parseInt(e.target.value) || 0))}
                className="w-full bg-neutral-950 border border-white/10 px-3 py-1.5 rounded text-xs text-white font-black font-mono focus:outline-none focus:ring-1 focus:ring-orange-brand"
              />
            </div>

            <div className="bg-[#121212] p-3 rounded-lg border border-white/5">
              <label className="text-[9px] uppercase font-bold text-white/40 block mb-1 font-mono tracking-wider">Work Duration (s)</label>
              <input
                type="number"
                min="1"
                value={workTime}
                onChange={e => setWorkTime(Math.max(1, parseInt(e.target.value) || 1))}
                className="w-full bg-neutral-950 border border-white/10 px-3 py-1.5 rounded text-xs text-white font-black font-mono focus:outline-none focus:ring-1 focus:ring-orange-brand"
              />
            </div>

            <div className="bg-[#121212] p-3 rounded-lg border border-white/5">
              <label className="text-[9px] uppercase font-bold text-white/40 block mb-1 font-mono tracking-wider">Rest Duration (s)</label>
              <input
                type="number"
                min="0"
                value={restTime}
                onChange={e => setRestTime(Math.max(0, parseInt(e.target.value) || 0))}
                className="w-full bg-neutral-950 border border-white/10 px-3 py-1.5 rounded text-xs text-white font-black font-mono focus:outline-none focus:ring-1 focus:ring-orange-brand"
              />
            </div>

            <div className="bg-[#121212] p-3 rounded-lg border border-white/5">
              <label className="text-[9px] uppercase font-bold text-white/40 block mb-1 font-mono tracking-wider">Cycles / Rounds</label>
              <input
                type="number"
                min="1"
                value={cycles}
                onChange={e => setCycles(Math.max(1, parseInt(e.target.value) || 1))}
                className="w-full bg-neutral-950 border border-white/10 px-3 py-1.5 rounded text-xs text-white font-black font-mono focus:outline-none focus:ring-1 focus:ring-orange-brand"
              />
            </div>

            <div className="bg-[#121212] p-3 rounded-lg border border-white/5">
              <label className="text-[9px] uppercase font-bold text-white/40 block mb-1 font-mono tracking-wider">Sets Count</label>
              <input
                type="number"
                min="1"
                value={sets}
                onChange={e => setSets(Math.max(1, parseInt(e.target.value) || 1))}
                className="w-full bg-neutral-950 border border-white/10 px-3 py-1.5 rounded text-xs text-white font-black font-mono focus:outline-none focus:ring-1 focus:ring-orange-brand"
              />
            </div>

            <div className="bg-[#121212] p-3 rounded-lg border border-white/5">
              <label className="text-[9px] uppercase font-bold text-white/40 block mb-1 font-mono tracking-wider">Cooldown (s)</label>
              <input
                type="number"
                min="0"
                value={cooldownTime}
                onChange={e => setCooldownTime(Math.max(0, parseInt(e.target.value) || 0))}
                className="w-full bg-neutral-950 border border-white/10 px-3 py-1.5 rounded text-xs text-white font-black font-mono focus:outline-none focus:ring-1 focus:ring-orange-brand"
              />
            </div>
          </div>
        ) : (
          <div className="bg-[#121212] p-5 rounded-xl border border-white/5 space-y-3.5">
            <div className="flex justify-between text-xs font-mono font-bold uppercase text-white/40">
              <span>Set Projections</span>
              <span className="text-white font-black">Set {currentSet} of {sets}</span>
            </div>
            <div className="flex justify-between text-xs font-mono font-bold uppercase text-white/40">
              <span>Cycle Progress</span>
              <span className="text-white font-black">Round {currentCycle} of {cycles}</span>
            </div>
          </div>
        )}

        {/* Start button togglers */}
        {phase === 'idle' || phase === 'done' ? (
          <button
            onClick={startSession}
            id="start-interval-btn"
            className="w-full flex items-center justify-center gap-2 py-3.5 bg-orange-brand hover:bg-[#D96B1E] text-black text-xs font-black rounded-lg uppercase tracking-widest transition-all cursor-pointer shadow-[0_4px_10px_rgba(242,125,38,0.25)]"
          >
            <Play className="w-4 h-4 text-black stroke-[3px]" /> Begin Workout Session
          </button>
        ) : (
          <div className="flex gap-2">
            {isRunning ? (
              <button
                onClick={pauseSession}
                id="pause-interval-btn"
                className="flex-1 py-3 bg-white hover:bg-neutral-200 text-black text-xs font-black rounded-lg uppercase tracking-widest transition-all cursor-pointer flex items-center justify-center gap-1.5"
              >
                <Pause className="w-4 h-4" /> Pause
              </button>
            ) : (
              <button
                onClick={startSession}
                id="resume-interval-btn"
                className="flex-1 py-3 bg-orange-brand hover:bg-[#D96B1E] text-black text-xs font-black rounded-lg uppercase tracking-widest transition-all cursor-pointer flex items-center justify-center gap-1.5"
              >
                <Play className="w-4 h-4" /> Resume
              </button>
            )}
            <button
              onClick={resetSession}
              id="reset-interval-btn"
              className="py-3 px-4 border border-white/10 text-white hover:bg-white/5 rounded-lg text-xs font-black uppercase tracking-widest transition-all cursor-pointer"
            >
              <RotateCcw className="w-4 h-4" />
            </button>
          </div>
        )}
      </div>

      {/* Massive Visual Display Screen */}
      <div className="lg:col-span-12 xl:col-span-7 flex flex-col items-center justify-center bg-neutral-950 border border-white/10 rounded-2xl p-8 shadow-xl min-h-[350px]">
        {phase === 'idle' ? (
          <div className="text-center py-10">
            <div className="w-16 h-16 rounded-full bg-[#121212] border border-white/5 flex items-center justify-center text-orange-brand mx-auto mb-4 animate-bounce">
              <Zap className="w-6 h-6" />
            </div>
            <h3 className="text-xs font-black uppercase tracking-widest text-white mb-1">Telemetry Signal Clear</h3>
            <p className="text-[10px] font-mono text-white/40 max-w-xs mx-auto uppercase tracking-wide">
              Configure metrics on the session console and initialize loops to project stages.
            </p>
          </div>
        ) : (
          <div className="w-full space-y-6 text-center">
            {/* Status dynamic color badge */}
            <div className={`p-8 rounded-xl border text-center transition-all duration-500 flex flex-col items-center justify-center ${getPhaseColor()}`}>
              <span className="text-[10px] font-mono font-bold tracking-[0.3em] uppercase mb-1">{getPhaseName()}</span>
              
              <span className="text-6xl sm:text-8xl font-black font-mono tracking-tight my-2">
                {timeLeft}s
              </span>

              {phase !== 'done' && (
                <div className="w-full max-w-sm bg-black/20 rounded-full h-1 overflow-hidden mt-4">
                  <div className="bg-current h-full transition-all duration-300" style={{ width: `${percent}%` }} />
                </div>
              )}
            </div>

            {/* Sub labels split stats */}
            {phase !== 'done' && (
              <div className="grid grid-cols-2 gap-4">
                <div className="border border-white/10 bg-[#121212]/40 p-4 rounded-xl text-center">
                  <span className="text-[9px] text-white/40 font-mono block uppercase tracking-wider mb-1">ROUND INDEX</span>
                  <span className="text-2xl font-black text-white font-mono">
                    {currentCycle} <span className="text-white/20 font-normal">/</span> {cycles}
                  </span>
                </div>
                <div className="border border-white/10 bg-[#121212]/40 p-4 rounded-xl text-center">
                  <span className="text-[9px] text-white/40 font-mono block uppercase tracking-wider mb-1">ACTIVE SET</span>
                  <span className="text-2xl font-black text-white font-mono">
                    {currentSet} <span className="text-white/20 font-normal">/</span> {sets}
                  </span>
                </div>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
