import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Bell, Plus, Trash2, Volume2, AlertCircle, RefreshCw, Sparkles, Check } from 'lucide-react';
import { Alarm } from '../types';
import { playSound, stopSound, SOUND_TYPES } from '../lib/audio';

interface AlarmTabProps {
  alarms: Alarm[];
  setAlarms: React.Dispatch<React.SetStateAction<Alarm[]>>;
}

const DAYS_SHORT = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];

export default function AlarmTab({ alarms, setAlarms }: AlarmTabProps) {
  const [alarmTime, setAlarmTime] = useState<string>('07:00');
  const [alarmLabel, setAlarmLabel] = useState<string>('');
  const [repeatDays, setRepeatDays] = useState<number[]>([]);
  const [selectedSound, setSelectedSound] = useState<string>('alarm_bell');
  const [previewingId, setPreviewingId] = useState<string | null>(null);

  useEffect(() => {
    return () => {
      stopSound('preview_alarm');
    };
  }, []);

  const handlePreviewSound = (soundType: string) => {
    if (previewingId === soundType) {
      stopSound('preview_alarm');
      setPreviewingId(null);
    } else {
      stopSound('preview_alarm');
      setPreviewingId(soundType);
      playSound(soundType, 'preview_alarm', false);
      setTimeout(() => {
        setPreviewingId(prev => prev === soundType ? null : prev);
      }, 2500);
    }
  };

  const toggleDaySelection = (dayIndex: number) => {
    setRepeatDays(prev => 
      prev.includes(dayIndex) 
        ? prev.filter(d => d !== dayIndex) 
        : [...prev, dayIndex].sort((a, b) => a - b)
    );
  };

  const addAlarm = (e: React.FormEvent) => {
    e.preventDefault();
    if (!alarmTime) return;

    const newAlarm: Alarm = {
      id: crypto.randomUUID(),
      time: alarmTime,
      label: alarmLabel.trim() || 'Alarm Clock',
      isEnabled: true,
      repeatDays: repeatDays,
      soundType: selectedSound,
      isRinging: false,
      snoozeCount: 0
    };

    setAlarms(prev => [newAlarm, ...prev].sort((a, b) => a.time.localeCompare(b.time)));
    // Reset Form
    setAlarmLabel('');
    setRepeatDays([]);
  };

  const deleteAlarm = (id: string) => {
    stopSound(id);
    setAlarms(prev => prev.filter(al => al.id !== id));
  };

  const toggleAlarmEnabled = (id: string) => {
    setAlarms(prev => prev.map(al => {
      if (al.id === id) {
        if (al.isEnabled) {
          stopSound(al.id);
          return { ...al, isEnabled: false, isRinging: false, snoozeCount: 0 };
        }
        return { ...al, isEnabled: true };
      }
      return al;
    }));
  };

  const handleDismissAlarm = (id: string) => {
    stopSound(id);
    setAlarms(prev => prev.map(al => {
      if (al.id === id) {
        return { ...al, isRinging: false, snoozeCount: 0 };
      }
      return al;
    }));
  };

  const handleSnoozeAlarm = (id: string) => {
    stopSound(id);
    setAlarms(prev => prev.map(al => {
      if (al.id === id) {
        // Parse time and add 5 minutes
        const [h, m] = al.time.split(':').map(Number);
        let newM = m + 5;
        let newH = h;
        if (newM >= 60) {
          newM -= 60;
          newH = (newH + 1) % 24;
        }
        const paddedH = newH.toString().padStart(2, '0');
        const paddedM = newM.toString().padStart(2, '0');
        const newTime = `${paddedH}:${paddedM}`;

        return {
          ...al,
          time: newTime,
          isRinging: false,
          snoozeCount: al.snoozeCount + 1
        };
      }
      return al;
    }));
  };

  const formatAmPm = (time24: string): string => {
    const [h, m] = time24.split(':').map(Number);
    const ampm = h >= 12 ? 'PM' : 'AM';
    const h12 = h % 12 || 12;
    return `${h12.toString().padStart(2, '0')}:${m.toString().padStart(2, '0')} ${ampm}`;
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
      {/* Alarm Setup Configurator */}
      <div id="alarm-creator-card" className="lg:col-span-12 xl:col-span-5 bg-neutral-950 border border-white/10 rounded-2xl p-6 shadow-xl relative overflow-hidden">
        
        <div className="flex items-center gap-3 mb-6">
          <div className="p-3 bg-[#1A1A1A] rounded-xl text-orange-brand">
            <Bell className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-sm font-black text-white uppercase tracking-wider">Set Awake Alarm</h2>
            <p className="text-[10px] text-white/40 tracking-wide font-mono uppercase">Precision scheduling system</p>
          </div>
        </div>

        <form onSubmit={addAlarm} className="space-y-6">
          {/* Time Picker */}
          <div>
            <label className="text-[10px] font-bold text-white/40 uppercase tracking-widest block mb-2 font-mono">Select Alarm Time</label>
            <input
              type="time"
              id="alarm-time-picker"
              value={alarmTime}
              onChange={e => setAlarmTime(e.target.value)}
              className="w-full text-center text-4xl font-black font-mono bg-[#121212] border border-white/10 rounded-lg py-3 text-white focus:outline-none focus:ring-1 focus:ring-orange-brand"
            />
          </div>

          {/* Alarm Label */}
          <div>
            <label className="text-[10px] font-bold text-white/40 uppercase tracking-widest block mb-2 font-mono">Alarm Occasion / Label</label>
            <input
              type="text"
              id="alarm-label-input"
              value={alarmLabel}
              onChange={e => setAlarmLabel(e.target.value)}
              placeholder="e.g. Wake up workout, Morning Standup"
              maxLength={40}
              className="w-full px-4 py-3 bg-[#121212] text-xs font-semibold uppercase tracking-wider border border-white/10 rounded-lg text-white placeholder-white/20 focus:outline-none focus:ring-1 focus:ring-orange-brand"
            />
          </div>

          {/* Repeat Days Selection */}
          <div>
            <label className="text-[10px] font-bold text-white/40 uppercase tracking-widest block mb-2 font-mono">Repeat Weekly Cycles</label>
            <div className="flex items-center justify-between gap-1 p-1 bg-[#121212] rounded-xl border border-white/5">
              {DAYS_SHORT.map((day, idx) => {
                const isSelected = repeatDays.includes(idx);
                return (
                  <button
                    key={day}
                    type="button"
                    id={`alarm-day-btn-${day.toLowerCase()}`}
                    onClick={() => toggleDaySelection(idx)}
                    className={`flex-1 py-1.5 text-xs font-black rounded-lg text-center transition-all cursor-pointer ${
                      isSelected 
                        ? 'bg-orange-brand text-black' 
                        : 'text-white/60 hover:text-white hover:bg-white/5'
                    }`}
                  >
                    {day[0]}
                  </button>
                );
              })}
            </div>
            <p className="text-[9px] font-mono text-white/40 uppercase mt-1.5 tracking-wider">
              {repeatDays.length === 0 ? '• Plays once (temporary state)' : `• Repeats on: ${repeatDays.map(d => DAYS_SHORT[d]).join(', ')}`}
            </p>
          </div>

          {/* Sound Alert Selector */}
          <div>
            <label className="text-[10px] font-bold text-white/40 uppercase tracking-widest block mb-2 font-mono">Alert Audio Sound</label>
            <div className="space-y-1.5 max-h-40 overflow-y-auto pr-1">
              {SOUND_TYPES.map(sound => (
                <div
                  key={sound.id}
                  className={`flex items-center justify-between p-2.5 rounded-lg border ${
                    selectedSound === sound.id
                      ? 'bg-orange-brand border-orange-brand text-black font-extrabold'
                      : 'bg-neutral-900/50 border-white/5 hover:bg-neutral-900 text-white/80'
                  } transition-all`}
                >
                  <label className="flex items-center gap-2.5 cursor-pointer flex-1 py-1 text-[11px] font-black uppercase tracking-wider">
                    <input
                      type="radio"
                      name="alarm-sound"
                      checked={selectedSound === sound.id}
                      onChange={() => setSelectedSound(sound.id)}
                      className="sr-only"
                    />
                    <div className={`w-3.5 h-3.5 rounded-full border-2 flex items-center justify-center ${selectedSound === sound.id ? 'border-black' : 'border-neutral-700'}`}>
                      {selectedSound === sound.id && <div className="w-1.5 h-1.5 rounded-full bg-black" />}
                    </div>
                    {sound.name}
                  </label>
                  <button
                    type="button"
                    onClick={() => handlePreviewSound(sound.id)}
                    className={`p-1.5 rounded-md border hover:scale-105 transition-all cursor-pointer ${
                      selectedSound === sound.id
                        ? 'bg-black/10 border-black/20 text-black'
                        : 'bg-neutral-950 border-white/5 text-white/60 hover:text-white'
                    }`}
                  >
                    <Volume2 className={`w-3.5 h-3.5 ${previewingId === sound.id ? 'animate-bounce text-red-500' : ''}`} />
                  </button>
                </div>
              ))}
            </div>
          </div>

          <button
            type="submit"
            id="create-alarm-btn"
            className="w-full flex items-center justify-center gap-2 py-3.5 bg-orange-brand hover:bg-[#D96B1E] text-black text-xs font-black rounded-lg uppercase tracking-widest transition-all cursor-pointer shadow-[0_4px_10px_rgba(242,125,38,0.25)]"
          >
            <Plus className="w-4 h-4 text-black stroke-[3px]" /> Save Alarm
          </button>
        </form>
      </div>

      {/* Alarms List Display */}
      <div className="lg:col-span-12 xl:col-span-7 space-y-4">
        <h3 className="text-[10px] font-mono font-bold text-white/40 uppercase tracking-widest pb-2 border-b border-white/5">
          SCHEDULED ALARMS ({alarms.length})
        </h3>

        <AnimatePresence mode="popLayout">
          {alarms.length === 0 ? (
            <motion.div
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              className="bg-neutral-950 border border-dashed border-white/10 rounded-2xl p-12 text-center"
            >
              <div className="inline-flex items-center justify-center p-4 bg-[#141414] rounded-xl border border-white/5 text-white/30 mb-4 animate-pulse">
                <Bell className="w-6 h-6 text-orange-brand" />
              </div>
              <h4 className="text-xs font-black uppercase tracking-widest text-white mb-1">Grid System Calibrated</h4>
              <p className="text-[10px] font-mono text-white/40 max-w-xs mx-auto uppercase tracking-wide">
                Configure your desired wake up intervals on the left form to schedule active slots.
              </p>
            </motion.div>
          ) : (
            <div className="space-y-4">
              {alarms.map(alarm => {
                const alarmSoundObj = SOUND_TYPES.find(s => s.id === alarm.soundType);

                return (
                  <motion.div
                    key={alarm.id}
                    id={`active-alarm-${alarm.id}`}
                    layout
                    initial={{ opacity: 0, scale: 0.95 }}
                    animate={{ opacity: 1, scale: 1 }}
                    exit={{ opacity: 0, scale: 0.9 }}
                    className={`relative overflow-hidden bg-neutral-950 border rounded-xl p-5 shadow-xl transition-all duration-300 ${
                      alarm.isRinging
                        ? 'border-red-500/80 shadow-[0_0_30px_rgba(239,68,68,0.2)] bg-red-500/[0.04]'
                        : alarm.isEnabled
                          ? 'border-white/10 hover:border-white/20'
                          : 'border-white/5 bg-neutral-950/40 opacity-40'
                    }`}
                  >
                    {/* Ringing flashes */}
                    {alarm.isRinging && (
                      <div className="absolute inset-0 bg-red-500/5 animate-pulse pointer-events-none" />
                    )}

                    <div className="flex justify-between items-start gap-4">
                      <div>
                        {/* Time display in 12h formatting */}
                        <div className="flex items-baseline gap-2">
                          <span className={`text-3xl font-black font-mono tracking-tight ${alarm.isEnabled ? 'text-white' : 'text-white/40'}`}>
                            {formatAmPm(alarm.time)}
                          </span>
                          {alarm.isRinging && (
                            <span className="text-[10px] font-mono font-bold uppercase text-red-500 animate-pulse tracking-widest flex items-center gap-1">
                              <Sparkles className="w-3.5 h-3.5 text-red-400 animate-bounce" /> RINGING
                            </span>
                          )}
                          {alarm.snoozeCount > 0 && (
                            <span className="px-2 py-0.5 rounded bg-orange-brand/20 text-orange-brand text-[9px] font-mono tracking-wider uppercase font-bold">
                              SNOOZED ({alarm.snoozeCount})
                            </span>
                          )}
                        </div>

                        <h4 className="font-extrabold text-white text-xs uppercase tracking-wider mt-2">{alarm.label}</h4>
                        <p className="text-[9px] font-mono text-white/40 uppercase mt-0.5 tracking-wider">
                          Repeat: {alarm.repeatDays.length === 0 ? 'Once' : alarm.repeatDays.map(d => DAYS_SHORT[d]).join(', ')}
                          {alarmSoundObj && ` • Tone: ${alarmSoundObj.name}`}
                        </p>
                      </div>

                      <div className="flex items-center gap-3">
                        {/* Custom visual switch for Enabled toggle */}
                        <button
                          onClick={() => toggleAlarmEnabled(alarm.id)}
                          className={`w-11 h-6 rounded-full flex items-center p-0.5 transition-colors cursor-pointer ${
                            alarm.isEnabled ? 'bg-orange-brand justify-end' : 'bg-white/10 justify-start'
                          }`}
                          title={alarm.isEnabled ? 'Disable Alarm' : 'Enable Alarm'}
                        >
                          <motion.div layout className={`w-5 h-5 rounded-full shadow-sm ${alarm.isEnabled ? 'bg-black' : 'bg-white/40'}`} />
                        </button>

                        <button
                          onClick={() => deleteAlarm(alarm.id)}
                          className="text-white/40 hover:text-red-500 p-1.5 rounded-md hover:bg-white/5 transition-colors cursor-pointer"
                          title="Delete Alarm"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </div>

                    {/* Ringing alarm active triggers panel */}
                    {alarm.isRinging && (
                      <div className="flex items-center gap-3 mt-5 relative z-10">
                        <button
                          onClick={() => handleDismissAlarm(alarm.id)}
                          className="flex-1 py-2 bg-red-650 hover:bg-red-700 active:scale-95 text-white font-black uppercase tracking-wider rounded-md text-[10px] flex items-center justify-center gap-1.5 transition-all shadow-md shadow-red-500/20 cursor-pointer"
                        >
                          <Check className="w-4 h-4 stroke-[3px]" /> Dismiss Alarm
                        </button>
                        <button
                          onClick={() => handleSnoozeAlarm(alarm.id)}
                          className="flex-1 py-2 bg-amber-500 hover:bg-amber-600 active:scale-95 text-black font-black uppercase tracking-wider rounded-md text-[10px] flex items-center justify-center gap-1.5 transition-all cursor-pointer"
                        >
                          <RefreshCw className="w-4 h-4 animate-spin-slow text-black" /> Snooze 5 Min
                        </button>
                      </div>
                    )}
                  </motion.div>
                );
              })}
            </div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}
