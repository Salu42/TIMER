import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Calendar, Plus, Trash2, Clock, Sparkles } from 'lucide-react';
import { CountdownEvent } from '../types';

interface CountdownTabProps {
  events: CountdownEvent[];
  setEvents: React.Dispatch<React.SetStateAction<CountdownEvent[]>>;
}

export default function CountdownTab({ events, setEvents }: CountdownTabProps) {
  const [label, setLabel] = useState<string>('');
  const [targetDateStr, setTargetDateStr] = useState<string>('');
  const [now, setNow] = useState<number>(Date.now());

  // Keep state updated for dynamic countdowns
  useEffect(() => {
    const timer = setInterval(() => {
      setNow(Date.now());
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  const addEvent = (e: React.FormEvent) => {
    e.preventDefault();
    if (!label.trim() || !targetDateStr) return;

    const newEvent: CountdownEvent = {
      id: crypto.randomUUID(),
      label: label.trim(),
      targetDate: targetDateStr,
      soundType: 'chime',
      isCompleted: false
    };

    setEvents(prev => [newEvent, ...prev]);
    setLabel('');
    setTargetDateStr('');
  };

  const deleteEvent = (id: string) => {
    setEvents(prev => prev.filter(ev => ev.id !== id));
  };

  const getRemainingTime = (targetIso: string) => {
    const targetMs = new Date(targetIso).getTime();
    const diff = targetMs - now;

    if (diff <= 0) {
      return { days: 0, hours: 0, minutes: 0, seconds: 0, expired: true };
    }

    const days = Math.floor(diff / (1000 * 60 * 60 * 24));
    const hours = Math.floor((diff / (1000 * 60 * 60)) % 24);
    const minutes = Math.floor((diff / (1000 * 60)) % 60);
    const seconds = Math.floor((diff / 1000) % 60);

    return { days, hours, minutes, seconds, expired: false };
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
      {/* Event Setup Configurator */}
      <div id="event-creator-card" className="lg:col-span-12 xl:col-span-5 bg-neutral-950 border border-white/10 rounded-2xl p-6 shadow-xl relative overflow-hidden">
        
        <div className="flex items-center gap-3 mb-6">
          <div className="p-3 bg-[#1A1A1A] rounded-xl text-orange-brand">
            <Calendar className="w-5 h-5 animate-pulse" />
          </div>
          <div>
            <h2 className="text-sm font-black text-white uppercase tracking-wider">Milestone Chronograph</h2>
            <p className="text-[10px] text-white/40 tracking-wide font-mono uppercase">Track launch schedules</p>
          </div>
        </div>

        <form onSubmit={addEvent} className="space-y-5">
          <div>
            <label className="text-[10px] font-bold text-white/40 uppercase tracking-widest block mb-2 font-mono">Event Name / Label</label>
            <input
              type="text"
              id="event-title-input"
              value={label}
              onChange={e => setLabel(e.target.value)}
              placeholder="e.g. Launch Day, Milestone Goal"
              maxLength={40}
              className="w-full px-4 py-3 bg-[#121212] text-xs font-semibold uppercase tracking-wider border border-white/10 rounded-lg text-white placeholder-white/20 focus:outline-none focus:ring-1 focus:ring-orange-brand"
            />
          </div>

          <div>
            <label className="text-[10px] font-bold text-white/40 uppercase tracking-widest block mb-2 font-mono">Target Date & Time</label>
            <input
              type="datetime-local"
              id="event-date-picker"
              value={targetDateStr}
              onChange={e => setTargetDateStr(e.target.value)}
              className="w-full px-4 py-3 bg-[#121212] text-xs font-semibold uppercase tracking-wider border border-white/10 rounded-lg text-white focus:outline-none focus:ring-1 focus:ring-orange-brand font-mono"
            />
          </div>

          <button
            type="submit"
            id="create-event-btn"
            className="w-full flex items-center justify-center gap-2 py-3.5 bg-orange-brand hover:bg-[#D96B1E] text-black text-xs font-black rounded-lg uppercase tracking-widest transition-all cursor-pointer shadow-[0_4px_10px_rgba(242,125,38,0.25)]"
          >
            <Plus className="w-4 h-4 text-black stroke-[3px]" /> Track Milestone
          </button>
        </form>
      </div>

      {/* Target Milestone Listing Grid */}
      <div className="lg:col-span-12 xl:col-span-7 space-y-4">
        <h3 className="text-[10px] font-mono font-bold text-white/40 uppercase tracking-widest pb-2 border-b border-white/5">
          MILESTONE EVENTS ({events.length})
        </h3>

        <AnimatePresence mode="popLayout">
          {events.length === 0 ? (
            <motion.div
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              className="bg-neutral-950 border border-dashed border-white/10 rounded-2xl p-12 text-center"
            >
              <div className="inline-flex items-center justify-center p-4 bg-[#141414] rounded-xl border border-white/5 text-white/30 mb-4 animate-pulse">
                <Clock className="w-6 h-6 text-orange-brand" />
              </div>
              <h4 className="text-xs font-black uppercase tracking-widest text-white mb-1">Chronology Stack Clear</h4>
              <p className="text-[10px] font-mono text-white/40 max-w-xs mx-auto uppercase tracking-wide">
                Target custom calendar intervals on the left grid system to plot milestones.
              </p>
            </motion.div>
          ) : (
            <div className="gap-4 grid grid-cols-1">
              {events.map(event => {
                const rem = getRemainingTime(event.targetDate);
                const eventFormattedDate = new Date(event.targetDate).toLocaleDateString(undefined, {
                  weekday: 'short',
                  year: 'numeric',
                  month: 'short',
                  day: 'numeric',
                  hour: '2-digit',
                  minute: '2-digit'
                });

                return (
                  <motion.div
                    key={event.id}
                    id={`active-event-${event.id}`}
                    layout
                    initial={{ opacity: 0, scale: 0.95 }}
                    animate={{ opacity: 1, scale: 1 }}
                    exit={{ opacity: 0, scale: 0.9 }}
                    className={`bg-neutral-950 border rounded-xl p-5 shadow-xl transition-all duration-300 flex flex-col justify-between ${
                      rem.expired 
                        ? 'border-white/5 bg-neutral-950/40 opacity-40'
                        : 'border-white/10 hover:border-white/20'
                    }`}
                  >
                    <div className="flex justify-between items-start gap-4 mb-4">
                      <div>
                        <h4 className="text-sm font-black text-white uppercase tracking-wider">{event.label}</h4>
                        <p className="text-[9px] font-mono text-white/40 uppercase tracking-widest mt-1">
                          Target: {eventFormattedDate}
                        </p>
                      </div>
                      <button
                        onClick={() => deleteEvent(event.id)}
                        className="text-white/40 hover:text-red-500 p-1.5 rounded-md hover:bg-white/5 transition-colors cursor-pointer"
                        title="Delete Milestone"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>

                    {rem.expired ? (
                      <div className="flex items-center gap-2 text-[#10B981] bg-[#10B981]/10 border border-[#10B981]/20 rounded-lg p-3.5 mt-1">
                        <Sparkles className="w-4 h-4 text-[#10B981] animate-pulse" />
                        <span className="text-[10px] font-mono font-bold uppercase tracking-wider">This milestone sequence has been reached!</span>
                      </div>
                    ) : (
                      <div className="grid grid-cols-4 gap-2 text-center mt-1">
                        <div className="bg-[#121212] border border-white/5 py-3 px-2 rounded-lg">
                          <span className="text-3xl font-black font-mono text-white block leading-none">{rem.days}</span>
                          <span className="text-[8px] text-white/40 uppercase tracking-widest block font-bold mt-1.5 font-mono">Days</span>
                        </div>
                        <div className="bg-[#121212] border border-white/5 py-3 px-2 rounded-lg">
                          <span className="text-3xl font-black font-mono text-white block leading-none">{rem.hours.toString().padStart(2, '0')}</span>
                          <span className="text-[8px] text-white/40 uppercase tracking-widest block font-bold mt-1.5 font-mono">Hours</span>
                        </div>
                        <div className="bg-[#121212] border border-white/5 py-3 px-2 rounded-lg">
                          <span className="text-3xl font-black font-mono text-white block leading-none">{rem.minutes.toString().padStart(2, '0')}</span>
                          <span className="text-[8px] text-white/40 uppercase tracking-widest block font-bold mt-1.5 font-mono">Mins</span>
                        </div>
                        <div className="bg-[#121212] border border-orange-brand/20 py-3 px-2 rounded-lg">
                          <span className="text-3xl font-black font-mono text-orange-brand block leading-none">{rem.seconds.toString().padStart(2, '0')}</span>
                          <span className="text-[8px] text-orange-brand/60 uppercase tracking-widest block font-bold mt-1.5 font-mono">Secs</span>
                        </div>
                      </div>
                    )}
                  </motion.div>
                );
              })}
            </div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}
