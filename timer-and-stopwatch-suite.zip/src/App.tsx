import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Hourglass, Timer as WatchIcon, Bell, Calendar, Dumbbell, Globe, Settings2, Info, Moon, Sun, Sparkles } from 'lucide-react';
import { Timer, Alarm, CountdownEvent, WorldClockItem } from './types';
import TimerTab from './components/TimerTab';
import StopwatchTab from './components/StopwatchTab';
import AlarmTab from './components/AlarmTab';
import CountdownTab from './components/CountdownTab';
import IntervalTab from './components/IntervalTab';
import WorldClockTab from './components/WorldClockTab';
import { playSound, stopAllSounds } from './lib/audio';

type Tab = 'timer' | 'stopwatch' | 'alarm' | 'interval' | 'countdown' | 'world_clock';

export default function App() {
  const [activeTab, setActiveTab] = useState<Tab>('timer');

  // Core state arrays synced with localStorage
  const [timers, setTimers] = useState<Timer[]>(() => {
    const saved = localStorage.getItem('suite_timers');
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        // Force reset running status on initial load to avoid ghost ticks
        return parsed.map((t: Timer) => ({ ...t, isRunning: false }));
      } catch (e) {
        // Fallback
      }
    }
    return [
      { id: 't1', label: 'Pasta Boiling 🍝', totalDuration: 480, remainingTime: 480, isRunning: false, isCompleted: false, soundType: 'classic_beep', createdAt: Date.now() - 1000 },
      { id: 't2', label: 'Tea Steeping 🫖', totalDuration: 180, remainingTime: 180, isRunning: false, isCompleted: false, soundType: 'chime', createdAt: Date.now() }
    ];
  });

  const [alarms, setAlarms] = useState<Alarm[]>(() => {
    const saved = localStorage.getItem('suite_alarms');
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        // Reset any ringing alarms on load
        return parsed.map((al: Alarm) => ({ ...al, isRinging: false }));
      } catch (e) {}
    }
    return [
      { id: 'a1', time: '06:30', label: 'Morning Gym Workout 🏋️', isEnabled: true, repeatDays: [1, 2, 3, 4, 5], soundType: 'alarm_bell', isRinging: false, snoozeCount: 0 },
      { id: 'a2', time: '08:00', label: 'Morning Standard Sync 🎙️', isEnabled: true, repeatDays: [1, 3, 5], soundType: 'chime', isRinging: false, snoozeCount: 0 }
    ];
  });

  const [events, setEvents] = useState<CountdownEvent[]>(() => {
    const saved = localStorage.getItem('suite_events');
    if (saved) {
      try { return JSON.parse(saved); } catch (e) {}
    }
    // Default to dynamic 3 months from now
    const targetDate = new Date();
    targetDate.setMonth(targetDate.getMonth() + 3);
    return [
      { id: 'e1', label: 'Summer Product Launch 🚀', targetDate: targetDate.toISOString(), soundType: 'chime', isCompleted: false }
    ];
  });

  const [worldClocks, setWorldClocks] = useState<WorldClockItem[]>(() => {
    const saved = localStorage.getItem('suite_clocks');
    if (saved) {
      try { return JSON.parse(saved); } catch (e) {}
    }
    return [
      { id: 'wc1', cityName: 'New York 🗽', timezone: 'America/New_York' },
      { id: 'wc2', cityName: 'London 💂', timezone: 'Europe/London' },
      { id: 'wc3', cityName: 'Geneva 🇨🇭', timezone: 'Europe/Zurich' },
      { id: 'wc4', cityName: 'Tokyo 🗼', timezone: 'Asia/Tokyo' }
    ];
  });

  // Track checked hours/minutes to avoid multiple alarm triggers in the same minute
  const checkedAlarmsRef = useRef<Record<string, number>>({});

  // Sync state with localStorage on change
  useEffect(() => {
    localStorage.setItem('suite_timers', JSON.stringify(timers));
  }, [timers]);

  useEffect(() => {
    localStorage.setItem('suite_alarms', JSON.stringify(alarms));
  }, [alarms]);

  useEffect(() => {
    localStorage.setItem('suite_events', JSON.stringify(events));
  }, [events]);

  useEffect(() => {
    localStorage.setItem('suite_clocks', JSON.stringify(worldClocks));
  }, [worldClocks]);

  // Master Active Ticker 1-second cadence
  useEffect(() => {
    const interval = setInterval(() => {
      const now = new Date();
      const currentMinStr = `${now.getHours().toString().padStart(2, '0')}:${now.getMinutes().toString().padStart(2, '0')}`;
      const weekday = now.getDay(); // 0-6

      // 1. Process active timers
      setTimers(prev => prev.map(t => {
        if (t.isRunning && t.remainingTime > 0) {
          const nextTime = t.remainingTime - 1;
          if (nextTime === 0) {
            playSound(t.soundType, t.id, true);
            return { ...t, remainingTime: 0, isRunning: false, isCompleted: true };
          }
          return { ...t, remainingTime: nextTime };
        }
        return t;
      }));

      // 2. Control alarm triggers
      setAlarms(prev => prev.map(al => {
        if (al.isEnabled && al.time === currentMinStr && !al.isRinging) {
          // Check repeat scheduling
          const matchesDay = al.repeatDays.length === 0 || al.repeatDays.includes(weekday);
          
          // Ensure we don't double trigger in the same exact minute
          const lastTriggeredTime = checkedAlarmsRef.current[al.id] || 0;
          const isFreshMinute = (Date.now() - lastTriggeredTime) > 61000;

          if (matchesDay && isFreshMinute) {
            checkedAlarmsRef.current[al.id] = Date.now();
            playSound(al.soundType, al.id, true);
            return { ...al, isRinging: true };
          }
        }
        return al;
      }));

    }, 1000);

    return () => clearInterval(interval);
  }, [alarms]);

  const tabs: Array<{ id: Tab; label: string; icon: React.ReactNode }> = [
    { id: 'timer', label: 'Countdown Timers', icon: <Hourglass className="w-4 h-4" /> },
    { id: 'stopwatch', label: 'Stopwatch', icon: <WatchIcon className="w-4 h-4" /> }
  ];

  const handleStopAllAlerts = () => {
    stopAllSounds();
    // Reset ringing on timers
    setTimers(prev => prev.map(t => t.isCompleted ? { ...t, isCompleted: false, remainingTime: t.totalDuration } : t));
    // Reset ringing on alarms
    setAlarms(prev => prev.map(al => al.isRinging ? { ...al, isRinging: false, snoozeCount: 0 } : al));
  };

  const isRingingAny = timers.some(t => t.isCompleted) || alarms.some(al => al.isRinging);
  const [utcTime, setUtcTime] = useState('');

  useEffect(() => {
    const updateUtc = () => {
      const now = new Date();
      const pad = (n: number) => n.toString().padStart(2, '0');
      setUtcTime(`${pad(now.getUTCHours())}:${pad(now.getUTCMinutes())}:${pad(now.getUTCSeconds())}`);
    };
    updateUtc();
    const interval = setInterval(updateUtc, 1000);
    return () => clearInterval(interval);
  }, []);

  return (
    <div className="min-h-screen bg-[#0A0A0A] text-white font-sans antialiased selection:bg-orange-brand selection:text-black pb-24 relative overflow-hidden">
      
      {/* Background Decorative Watermark Text */}
      <div className="absolute inset-0 flex items-center justify-center opacity-[0.015] pointer-events-none select-none z-0">
        <span className="text-[24vw] font-black italic tracking-tighter uppercase">CHRONOS</span>
      </div>

      {/* Dynamic Floating Global Alert Ringing Banner */}
      {isRingingAny && (
        <div id="ringing-banner" className="bg-orange-brand text-black selection:bg-black selection:text-white shadow-lg sticky top-0 z-50 animate-pulse">
          <div className="max-w-7xl mx-auto px-6 py-4 flex items-center justify-between gap-4">
            <div className="flex items-center gap-2.5">
              <Sparkles className="w-5 h-5 animate-bounce" />
              <span className="text-sm font-black tracking-wider uppercase">Active alert or timer is ringing!</span>
            </div>
            <button
              onClick={handleStopAllAlerts}
              id="global-stop-alarm-btn"
              className="px-6 py-2 bg-black text-white hover:bg-neutral-900 rounded-lg text-xs font-black uppercase tracking-widest transition-all shadow-sm cursor-pointer hover:scale-105"
            >
              Mute & Stop All Sounds
            </button>
          </div>
        </div>
      )}

      {/* Precision Header Section */}
      <header className="border-b border-white/10 bg-[#0A0A0A]/90 backdrop-blur-md sticky top-0 z-40">
        <div className="max-w-7xl mx-auto px-6 py-6 flex flex-col md:flex-row md:items-center md:justify-between gap-4">
          
          <div className="flex items-center gap-4">
            <div className="w-3 h-3 bg-orange-brand rounded-full animate-ping"></div>
            <div>
              <h1 className="text-sm font-bold tracking-[0.25em] text-white uppercase flex items-center gap-2">
                Timekeeper / Precision Suite
              </h1>
              <p className="text-[10px] text-white/40 tracking-wider font-mono uppercase mt-0.5">Swiss-Engine Calibration</p>
            </div>
          </div>

          <div className="flex gap-8 text-[10px] tracking-widest text-white/40 font-mono uppercase">
            <div>Status: <span className="text-white font-bold">Online</span></div>
            <div>UTC: <span className="text-orange-brand font-bold">{utcTime || '14:32:05'}</span></div>
            <div>Session: <span className="text-white font-bold">004</span></div>
          </div>

        </div>
      </header>

      <main className="max-w-7xl mx-auto px-6 mt-12 space-y-12 relative z-10">
        
        {/* Extreme Contrast Tabs Selection Strip */}
        <div className="flex items-center gap-1.5 overflow-x-auto p-1.5 bg-neutral-950 border border-white/10 rounded-xl scrollbar-none">
          {tabs.map(tab => {
            const isSelected = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                id={`tab-${tab.id}`}
                onClick={() => {
                  stopAllSounds(); 
                  setActiveTab(tab.id);
                }}
                className={`flex items-center gap-2 px-5 py-3 rounded-lg text-xs font-black uppercase tracking-widest whitespace-nowrap transition-all duration-200 cursor-pointer ${
                  isSelected
                    ? 'bg-orange-brand text-black font-extrabold shadow-md'
                    : 'text-white/60 hover:text-white hover:bg-white/5'
                }`}
              >
                {tab.icon}
                {tab.label}
              </button>
            );
          })}
        </div>

        {/* Dynamic Display Layout */}
        <div className="space-y-6">
          {activeTab === 'timer' && (
            <TimerTab timers={timers} setTimers={setTimers} />
          )}

          {activeTab === 'stopwatch' && (
            <StopwatchTab />
          )}

          {activeTab === 'alarm' && (
            <AlarmTab alarms={alarms} setAlarms={setAlarms} />
          )}

          {activeTab === 'interval' && (
            <IntervalTab />
          )}

          {activeTab === 'countdown' && (
            <CountdownTab events={events} setEvents={setEvents} />
          )}

          {activeTab === 'world_clock' && (
            <WorldClockTab worldClocks={worldClocks} setWorldClocks={setWorldClocks} />
          )}
        </div>

      </main>

      {/* Custom footer conforming to the specified brand guidelines */}
      <footer className="max-w-3xl mx-auto text-center mt-24 px-6 space-y-3 pb-8">
        <div className="w-12 h-[1px] bg-white/20 mx-auto"></div>
        <p className="text-[10px] font-mono tracking-widest uppercase text-white/40">
          Pure Client-Side Precision Engine • Persistent Storage Sync
        </p>
        <p className="text-[11px] font-bold text-white/60 italic">
          No external telemetry, zero tracking overheads, custom Web Audio synthesis
        </p>
      </footer>

      {/* Decorative Brand Orange Bottom Rail */}
      <div className="fixed bottom-0 left-0 h-1.5 bg-orange-brand w-full z-50 shadow-[0_-4px_20px_rgba(242,125,38,0.2)]"></div>

    </div>
  );
}
