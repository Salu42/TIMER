export interface Timer {
  id: string;
  label: string;
  totalDuration: number; // in seconds
  remainingTime: number; // in seconds
  isRunning: boolean;
  isCompleted: boolean;
  soundType: string;
  createdAt: number;
}

export interface Lap {
  id: string;
  lapNumber: number;
  lapTime: number; // in milliseconds
  splitTime: number; // in milliseconds
}

export interface Alarm {
  id: string;
  time: string; // "HH:MM" in 24h format
  label: string;
  isEnabled: boolean;
  repeatDays: number[]; // 0 for Sunday, 1 for Monday, etc. Empty means once
  soundType: string;
  isRinging: boolean;
  snoozeCount: number;
}

export interface CountdownEvent {
  id: string;
  label: string;
  targetDate: string; // ISO string or sound date string
  soundType: string;
  isCompleted: boolean;
}

export interface IntervalProfile {
  id: string;
  name: string;
  prepTime: number; // in seconds
  workTime: number; // in seconds
  restTime: number; // in seconds
  cycles: number;   // number of rounds per set
  sets: number;     // number of sets
  cooldownTime: number; // in seconds
}

export interface WorldClockItem {
  id: string;
  cityName: string;
  timezone: string; // e.g., "America/New_York"
}
