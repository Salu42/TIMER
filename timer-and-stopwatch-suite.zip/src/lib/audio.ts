// High-craft, cross-browser Web Audio API alert synthesizer
// Automatically falls back gracefully if AudioContext is blocked or not available

let audioCtx: AudioContext | null = null;
let activeIntervals: Map<string, number> = new Map();
let activeOscillators: Map<string, Array<{ osc: OscillatorNode; gain: GainNode }>> = new Map();

function getAudioContext() {
  if (!audioCtx) {
    audioCtx = new (window.AudioContext || (window as any).webkitAudioContext)();
  }
  if (audioCtx.state === 'suspended') {
    audioCtx.resume();
  }
  return audioCtx;
}

export const SOUND_TYPES = [
  { id: 'classic_beep', name: 'Digital Beep' },
  { id: 'chime', name: 'Ambient Chime' },
  { id: 'alarm_bell', name: 'Pulsing Siren' },
  { id: 'zen_gong', name: 'Zen Bowl Gong' },
  { id: 'marimba', name: 'Marimba Arpeggio' }
];

export function playSound(type: string, id: string, loop: boolean = false) {
  try {
    const ctx = getAudioContext();
    if (!ctx) return;

    // Direct user action might be needed, so we resume ctx
    if (ctx.state === 'suspended') {
      ctx.resume();
    }

    // Stop existing sound with this ID first
    stopSound(id);

    const oscillators: Array<{ osc: OscillatorNode; gain: GainNode }> = [];
    activeOscillators.set(id, oscillators);

    if (type === 'classic_beep') {
      const playBeep = () => {
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.connect(gain);
        gain.connect(ctx.destination);

        osc.type = 'square';
        osc.frequency.setValueAtTime(880, ctx.currentTime); // A5

        gain.gain.setValueAtTime(0, ctx.currentTime);
        gain.gain.linearRampToValueAtTime(0.15, ctx.currentTime + 0.01);
        gain.gain.setValueAtTime(0.15, ctx.currentTime + 0.12);
        gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.15);

        osc.start();
        osc.stop(ctx.currentTime + 0.16);
      };

      playBeep();
      if (loop) {
        const interval = window.setInterval(playBeep, 800);
        activeIntervals.set(id, interval);
      }
    } else if (type === 'chime') {
      const playChime = () => {
        const freqs = [523.25, 659.25, 783.99, 1046.50]; // C5, E5, G5, C6
        freqs.forEach((f, index) => {
          const osc = ctx.createOscillator();
          const gain = ctx.createGain();
          osc.connect(gain);
          gain.connect(ctx.destination);

          osc.type = 'sine';
          osc.frequency.setValueAtTime(f, ctx.currentTime + index * 0.08);

          gain.gain.setValueAtTime(0, ctx.currentTime);
          gain.gain.linearRampToValueAtTime(0.1, ctx.currentTime + index * 0.08 + 0.01);
          gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + index * 0.08 + 1.2);

          osc.start(ctx.currentTime + index * 0.08);
          osc.stop(ctx.currentTime + index * 0.08 + 1.3);
        });
      };

      playChime();
      if (loop) {
        const interval = window.setInterval(playChime, 2500);
        activeIntervals.set(id, interval);
      }
    } else if (type === 'alarm_bell') {
      const playSiren = () => {
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.connect(gain);
        gain.connect(ctx.destination);

        osc.type = 'sawtooth';
        osc.frequency.setValueAtTime(600, ctx.currentTime);
        osc.frequency.linearRampToValueAtTime(1000, ctx.currentTime + 0.2);
        osc.frequency.linearRampToValueAtTime(600, ctx.currentTime + 0.4);

        gain.gain.setValueAtTime(0, ctx.currentTime);
        gain.gain.linearRampToValueAtTime(0.08, ctx.currentTime + 0.02);
        gain.gain.linearRampToValueAtTime(0.08, ctx.currentTime + 0.38);
        gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.4);

        osc.start();
        osc.stop(ctx.currentTime + 0.45);
      };

      playSiren();
      if (loop) {
        const interval = window.setInterval(playSiren, 500);
        activeIntervals.set(id, interval);
      }
    } else if (type === 'zen_gong') {
      const playGong = () => {
        const baseFreq = 146.83; // D3 (Calming, resonant)
        const partials = [1, 1.5, 2, 2.7, 3.4, 4.2]; // Resonant overtone ratios

        partials.forEach((ratio, index) => {
          const osc = ctx.createOscillator();
          const gain = ctx.createGain();
          osc.connect(gain);
          gain.connect(ctx.destination);

          osc.type = index === 0 ? 'sine' : 'triangle';
          osc.frequency.setValueAtTime(baseFreq * ratio, ctx.currentTime);

          // Damp override for higher structures
          const amplitude = 0.15 / (index + 0.8);
          const duration = 4.0 / (index * 0.5 + 1.0);

          gain.gain.setValueAtTime(0, ctx.currentTime);
          gain.gain.linearRampToValueAtTime(amplitude, ctx.currentTime + 0.04);
          gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + duration);

          osc.start();
          osc.stop(ctx.currentTime + duration + 0.1);
        });
      };

      playGong();
      if (loop) {
        const interval = window.setInterval(playGong, 5000);
        activeIntervals.set(id, interval);
      }
    } else if (type === 'marimba') {
      const playMarimba = () => {
        // High, wooden sound pluck arpeggio
        const notes = [523.25, 587.33, 659.25, 783.99]; // C5, D5, E5, G5
        notes.forEach((f, idx) => {
          const osc = ctx.createOscillator();
          const gain = ctx.createGain();
          osc.connect(gain);
          gain.connect(ctx.destination);

          osc.type = 'triangle';
          osc.frequency.setValueAtTime(f, ctx.currentTime + idx * 0.1);

          gain.gain.setValueAtTime(0, ctx.currentTime);
          gain.gain.linearRampToValueAtTime(0.12, ctx.currentTime + idx * 0.1 + 0.005);
          gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + idx * 0.1 + 0.35);

          osc.start(ctx.currentTime + idx * 0.1);
          osc.stop(ctx.currentTime + idx * 0.1 + 0.4);
        });
      };

      playMarimba();
      if (loop) {
        const interval = window.setInterval(playMarimba, 1500);
        activeIntervals.set(id, interval);
      }
    }
  } catch (err) {
    console.error('Failed to play audio alert synthesized:', err);
  }
}

export function stopSound(id: string) {
  // Stop interval looping
  const interval = activeIntervals.get(id);
  if (interval) {
    clearInterval(interval);
    activeIntervals.delete(id);
  }

  // Stop active oscillators
  const oscillators = activeOscillators.get(id);
  if (oscillators) {
    oscillators.forEach(({ osc }) => {
      try {
        osc.stop();
      } catch (e) {
        // Already stopped/completed
      }
    });
    activeOscillators.delete(id);
  }
}

export function stopAllSounds() {
  activeIntervals.forEach((interval) => clearInterval(interval));
  activeIntervals.clear();

  activeOscillators.forEach((oscillators) => {
    oscillators.forEach(({ osc }) => {
      try {
        osc.stop();
      } catch (e) {}
    });
  });
  activeOscillators.clear();
}
